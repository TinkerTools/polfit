import numpy as np
import os
from . import gas
kB = 0.008314472471220214
atm_unit = 0.061019351687175
bar_unit = 0.060221417930000
prefactor = 30.348705333964077

KB_J = 1.38064852e-23 #J/K
E0 = 8.854187817620e-12
N_vis = 8.91e-4 #Pa.s
R=1.9872036E-3

tinkerpath = '/user/roseane/Applications/tinker-git_JP/tinker'
data_dir = '/user/roseane/HIPPO/reference_data'

mw_elements = {'H': 1.00794, 'HW': 1.00794,'He': 4.002602, 'Li': 6.941,
               'Be': 9.012182, 'B': 10.811, 'C': 12.0107,
               'N': 14.0067,'O': 15.9994,'OW': 15.9994,'F': 18.9984032,
               'Ne': 20.1797,'Na': 22.98976928,'Mg': 24.305,
               'Al': 26.9815386,'Si': 28.0855,'P': 30.973762,
               'S': 32.065,'Cl': 35.453,'Ar': 39.948,
               'K': 39.0983,'Ca': 40.078,'Sc': 44.955912,
               'Ti': 47.867,'V': 50.9415, 'Cr': 51.9961,
               'Mn': 54.938045,'Fe': 55.845,'Co': 58.933195,
               'Ni': 58.6934,'Cu': 63.546,'Zn': 65.409,
               'Ga': 69.723,'Ge': 72.64,'As': 74.9216,
               'Se': 78.96,'Br': 79.904,'Kr': 83.798,
               'Rb': 85.4678,'Sr': 87.62, 'Y': 88.90585,
               'Zr': 91.224,'Nb': 92.90638,'Mo': 95.94,
               'Tc': 98.9063,'Ru': 101.07,'Rh': 102.9055,
               'Pd': 106.42,'Ag': 107.8682,'Cd': 112.411,
               'In': 114.818,'Sn': 118.71,'Sb': 121.76,
               'Te': 127.6,'I': 126.90447,'Xe': 131.293,
               'Cs': 132.9054519,'Ba': 137.327,'La': 138.90547,
               'Ce': 140.116,'Pr': 140.90465,'Nd': 144.242,
               'Pm': 146.9151,'Sm': 150.36,'Eu': 151.964,
               'Gd': 157.25,'Tb': 158.92535,'Dy': 162.5,
               'Ho': 164.93032,'Er': 167.259,'Tm': 168.93421,
               'Yb': 173.04,'Lu': 174.967,'Hf': 178.49,
               'Ta': 180.9479,'W': 183.84,'Re': 186.207,
               'Os': 190.23,'Ir': 192.217,'Pt': 195.084,
               'Au': 196.966569,'Hg': 200.59,'Tl': 204.3833,
               'Pb': 207.2,'Bi': 208.9804,'Po': 208.9824,
               'At': 209.9871,'Rn': 222.0176,'Fr': 223.0197,
               'Ra': 226.0254,'Ac': 227.0278,'Th': 232.03806,
               'Pa': 231.03588,'U': 238.02891,'Np': 237.0482,
               'Pu': 244.0642,'Am': 243.0614,'Cm': 247.0703,
               'Bk': 247.0703,'Cf': 251.0796,'Es': 252.0829,
               'Fm': 257.0951,'Md': 258.0951,'No': 259.1009,
               'Lr': 262,'Rf': 267,'Db': 268,'Sg': 271,
               'Bh': 270,'Hs': 269,'Mt': 278,'Ds': 281,
               'Rg': 281,'Cn': 285,'Nh': 284,'Fl': 289,
               'Mc': 289,'Lv': 292,'Ts': 294,'Og': 294,
               'ZERO': 0} 

n_atoms_per_mol = {'Methanol': 6,
                   'MethylChloride': 5,
                   'Ethene': 6,
                   'Imidazolium': 10,
                   'Uracil': 12,
                   'PhosphoricAcid': 8,
                   'MethyleneFluoride': 5,
                   'MethylAmine': 7,
                   'MethylBromide': 5,
                   'AceticAcid': 8,
                   'MethyleneChloride': 5,
                   'MethylAmmonium': 8,
                   'Acetamide': 9,
                   'MethylSulfide': 6,
                   'Phenol': 13,
                   'Neopentane': 17,
                   'ChloroBenzene': 12,
                   'Acetate': 7,
                   'FluoroBenzene': 12,
                   'DihydrogenPhosphate': 7,
                   'MethyleneBromide': 5,
                   'BromoBenzene': 12,
                   'Indole': 16,
                   'MethylFluoride': 5,
                   'DimethylSulfide': 9,
                   'Pyrrolidine': 14,
                   'MethylAcetamide': 12,
                   'Pentane': 17,
                   'Pyridine': 11,
                   'Water': 3,
                   'HydrogenPhosphate': 6,
                   'DimethylSulfoxide': 10,
                   'Benzene': 12,
                   'Guanidinium': 10,
                   'Imidazole': 9,
                   'Cyclopentane': 15}

def bzavg(obs,boltz):
    """ Get the Boltzmann average of an observable. """
    if obs.ndim == 2:
        if obs.shape[0] == len(boltz) and obs.shape[1] == len(boltz):
            raise Exception('Error - both dimensions have length equal to number of snapshots, now confused!')
        elif obs.shape[0] == len(boltz):
            return np.sum(obs*boltz.reshape(-1,1),axis=0)/np.sum(boltz)
        elif obs.shape[1] == len(boltz):
            return np.sum(obs*boltz,axis=1)/np.sum(boltz)
        else:
            raise Exception('The dimensions are wrong!')
    elif obs.ndim == 1:
        return np.dot(obs,boltz)/sum(boltz)
    else:
        raise Exception('The number of dimensions can only be 1 or 2!')

#===========================================#
#| John's statisticalInefficiency function |#
#===========================================#
def statisticalInefficiency(A_n, B_n=None, fast=False, mintime=3, warn=True):

    """
    Compute the (cross) statistical inefficiency of (two) timeseries.

    Notes
      The same timeseries can be used for both A_n and B_n to get the autocorrelation statistical inefficiency.
      The fast method described in Ref [1] is used to compute g.

    References
      [1] J. D. Chodera, W. C. Swope, J. W. Pitera, C. Seok, and K. A. Dill. Use of the weighted
      histogram analysis method for the analysis of simulated and parallel tempering simulations.
      JCTC 3(1):26-41, 2007.

    Examples

    Compute statistical inefficiency of timeseries data with known correlation time.

    >>> import timeseries
    >>> A_n = timeseries.generateCorrelatedTimeseries(N=100000, tau=5.0)
    >>> g = statisticalInefficiency(A_n, fast=True)

    @param[in] A_n (required, numpy array) - A_n[n] is nth value of
    timeseries A.  Length is deduced from vector.

    @param[in] B_n (optional, numpy array) - B_n[n] is nth value of
    timeseries B.  Length is deduced from vector.  If supplied, the
    cross-correlation of timeseries A and B will be estimated instead of
    the autocorrelation of timeseries A.

    @param[in] fast (optional, boolean) - if True, will use faster (but
    less accurate) method to estimate correlation time, described in
    Ref. [1] (default: False)

    @param[in] mintime (optional, int) - minimum amount of correlation
    function to compute (default: 3) The algorithm terminates after
    computing the correlation time out to mintime when the correlation
    function furst goes negative.  Note that this time may need to be
    increased if there is a strong initial negative peak in the
    correlation function.

    @return g The estimated statistical inefficiency (equal to 1 + 2
    tau, where tau is the correlation time).  We enforce g >= 1.0.

    """
    # Create numpy copies of input arguments.
    A_n = np.array(A_n)
    if B_n is not None:
        B_n = np.array(B_n)
    else:
        B_n = np.array(A_n)
    # Get the length of the timeseries.
    N = A_n.shape[0]
    # Be sure A_n and B_n have the same dimensions.
    if A_n.shape != B_n.shape:
        print('A_n and B_n must have same dimensions.\n')
    
    # Initialize statistical inefficiency estimate with uncorrelated value.
    g = 1.0
    # Compute mean of each timeseries.
    mu_A = A_n.mean()
    mu_B = B_n.mean()
    # Make temporary copies of fluctuation from mean.
    dA_n = A_n.astype(np.float64) - mu_A
    dB_n = B_n.astype(np.float64) - mu_B
    # Compute estimator of covariance of (A,B) using estimator that will ensure C(0) = 1.
    sigma2_AB = (dA_n * dB_n).mean() # standard estimator to ensure C(0) = 1
    # Trap the case where this covariance is zero, and we cannot proceed.
    if sigma2_AB == 0:
        print('Sample covariance sigma_AB^2 = 0 -- cannot compute statistical inefficiency\n')
    # Accumulate the integrated correlation time by computing the normalized correlation time at
    # increasing values of t.  Stop accumulating if the correlation function goes negative, since
    # this is unlikely to occur unless the correlation function has decayed to the point where it
    # is dominated by noise and indistinguishable from zero.
    t = 1
    increment = 1
    while t < N-1:
        # compute normalized fluctuation correlation function at time t
        C = sum( dA_n[0:(N-t)]*dB_n[t:N] + dB_n[0:(N-t)]*dA_n[t:N] ) / (2.0 * float(N-t) * sigma2_AB)
        # Terminate if the correlation function has crossed zero and we've computed the correlation
        # function at least out to 'mintime'.
        if (C <= 0.0) and (t > mintime):
            break
        # Accumulate contribution to the statistical inefficiency.
        g += 2.0 * C * (1.0 - float(t)/float(N)) * float(increment)
        # Increment t and the amount by which we increment t.
        t += increment
        # Increase the interval if "fast mode" is on.
        if fast: increment += 1
    # g must be at least unity
    if g < 1.0: g = 1.0
    # Return the computed statistical inefficiency.
    return g

def mean_stderr(ts):
    """Return mean and standard deviation of a time series ts."""
    return np.mean(ts), \
      np.std(ts)*np.sqrt(statisticalInefficiency(ts, warn=False)/len(ts))

def convert_float(string):
    a = True
    try:
        a = float(string)
        err = False
    except:
        err = True
        a = -100
    return a, err

def compute_angle(a,b,c):
    a = np.asarray(a)
    b = np.asarray(b)
    c = np.asarray(c)

    ba = a - b
    bc = c - b

    cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc))
    angle = np.arccos(cosine_angle)

    return np.degrees(angle)

numboots = 1000

class Liquid(object):
    def __init__(self, sim_path,xyzfile='liquid.xyz',n_atoms_mol=None,temperature=298.15,equil=200,
                 logfile=None, analyzelog=None, gaslog=None):

        """syntax : Liquid(simulation_path, xyz_file_name,
        number of atoms per molecule or molecule name to search database,
        temp. of simulation,
        number of steps to consider as equilibration,
        name of log file of dynamics, name of analyze log file (optional)"""
        if '.xyz' not in xyzfile:
            xyzfile += '.xyz'
            self.xyzfile = xyzfile

        if isinstance(n_atoms_mol, int) or isinstance(n_atoms_mol, float):
            Nmonomer = int(n_atoms_mol)
            #self.Natoms = int(n_atoms_mol)
        elif isinstance(n_atoms_mol, str):
            try:
                Nmonomer = n_atoms_per_mol[n_atoms_mol]
                #self.Natoms = n_atoms_per_mol[n_atoms_mol]
            except:
                raise Exception('Cannot obtain number of atoms in molecule, please specify')

        self.xyzfile = xyzfile

        xyz_fn = os.path.join(sim_path,xyzfile)
        f = open(xyz_fn)
        lines = f.readlines()
        f.close()

        try:
            elements = [a.split()[1] for a in lines[1:]]
            float(mw_elements[elements[0]])
        except:
            elements = [a.split()[1] for a in lines[2:]]
            float(mw_elements[elements[0]])

        total_mass = 0
        for X in elements:
            total_mass += float(mw_elements[X])  

        self.mass = total_mass
        self.Nmol = int(len(elements)/Nmonomer)
        self.Nmonomer = Nmonomer
        self.Natoms = int(len(elements))

        R=1.9872036e-3
        T = temperature
        kT = R * T
        mBeta = -1.0 / kT
        Beta = 1.0 / kT

        self.kT = R * T
        self.equil = equil
        self.path = sim_path
        self.T = temperature
        self.avgPE = 0
        self.avgKE = 0
        self.gasAvgPE = 0

        self.KE = []
        self.PE = []

        edyn = []
        kdyn = []
        dens = []
        vol = []

        self.H = []
        self.avgPE = 0
        self.avgKE = 0
        
        self.PEmol = 0
        self.avgVol = 0
        self.avgRho = 0
        self.median_diffusion = 0
        self.alpha = 0
        self.kappa = 0
        self.Cp = 0

        self.Vol = []
        self.Rhos = []
        self.error = False
        error = []
        self.coords = np.array([])

        if logfile is not None:
            liqlog = os.path.join(sim_path,logfile)
                
            if os.path.isfile(liqlog):
                f = open(liqlog,'r')
                dt = f.readlines()
                f.close()

                for line in dt:
                    s = line.split()
                    if 'Current Potential' in line:
                        val, err = convert_float(s[2])
                        edyn.append(val)
                        error.append(err)
                    if 'Current Kinetic' in line:
                        val, err = convert_float(s[2])
                        kdyn.append(val)
                    if 'Density' in line:
                        val, err = convert_float(s[1])
                        dens.append(val)
                    if 'Lattice Lengths' in line:
                        val, err = convert_float(s[2])
                        vol.append(np.power(val,3))

                eq = int(equil)
                self.PE = np.array(edyn)
                self.KE = np.array(kdyn)

                frm_nm = min(self.PE.shape[0],self.KE.shape[0])
                self.H = self.PE[:frm_nm]+self.KE[:frm_nm]
                self.avgPE = self.PE[eq:].mean()
                self.avgKE = self.KE[eq:].mean()
                
                self.PEmol = self.avgPE/self.Nmol

                if any(error):
                    self.error = True

                if len(dens) == 0:
                    vol = np.array(vol)
                    conv = 1.6605387831627252
                    Rhos = conv * self.mass / vol

                else:
                    Rhos = np.array(dens)
                    vol = np.array(vol)

                self.avgVol, self.stdVol = mean_stderr(vol[eq:])
                self.avgRho, self.stdRho = mean_stderr(Rhos[eq:])

                self.Vol = np.copy(vol)
                self.Rhos = np.copy(Rhos)

                self.HV = 0

                L = self.H[eq:].shape[0]

                Nmol = self.Nmol
                NMol = self.Nmol
                
                self.alpha = self.calc_alpha()
                self.Cp = self.calc_cp()
                self.kappa = self.calc_kappa()
                
                self.dielectric = 0
                self.Dips = []
            
        if analyzelog is not None:
            anal_fn = os.path.join(sim_path,analyzelog)
        
            if os.path.isfile(anal_fn):
                f = open(anal_fn,'r')
                dt = f.readlines()
                f.close()

                self.analyzelog = anal_fn

                log = [a.strip('\n') for a in dt]
                dip = []
                for line in log:
                    s = line.split()
                    if 'Dipole X,Y,Z-Components' in line:
                        dip.append([float(s[i]) for i in range(-3,0)])

                if len(dip) > 0 and len(dip) == len(self.PE):
                    self.Dips = np.array(dip)                        
                    self.dielectric = self.calc_eps0()
                    
                else:
                    self.dielectric = 0
                    self.Dips = []
            else:
                self.analyzelog = None

        if gaslog is not None:
            if os.path.isfile(os.path.join(self.path,gaslog)):
                gas_fn = os.path.join(self.path,gaslog)
            else:
                gas_fn = gaslog
            gasdata = gas.GasLog(gas_fn,self.T)
            self.gasAvgPE = gasdata.avgPE
        
            self.HV = self.gasAvgPE - (self.PEmol) + kT


    def calc_alpha(self,h_ = [],v_ = [],b = None):
        kT = self.kT
        T = self.T
        eq = self.equil

        if len(h_) == 0:
            h_ = self.H[eq:]
        if len(v_) == 0:
            v_ = self.Vol[eq:]

        L = v_.shape[0]
        L2 = h_.shape[0]

        if L != L2:
            L = min(L,L2)
            h_ = h_[:L]
            v_ = v_[:L]
        if b is None: b = np.ones(L,dtype=float)

        return 1/(kT*T) * (bzavg(h_*v_,b)-bzavg(h_,b)*bzavg(v_,b))/bzavg(v_,b)

    def calc_kappa(self,v_ = []):
        KB_J = 1.38064852E-23
        eq = self.equil
        T = self.T

        if len(v_) == 0:
            V0 = (1e-30)*self.Vol[eq:]
        else:
            V0 = (1e-30)*v_
        
        volume_squared = V0*V0
        avg_volume = V0.mean()
        volume_fluct = (volume_squared.mean()-(avg_volume*avg_volume))

        return (1e11)*(volume_fluct/(KB_J*T*avg_volume))

    def calc_cp(self,h_=[],b=None):
        Nmol = self.Nmol
        eq = self.equil
        kT = self.kT
        T = self.T

        if len(h_) == 0:
            h_ = self.H[eq:]
        
        T = self.T
        kT = self.kT      
        L = h_.shape[0]
        if b is None: b = np.ones(L,dtype=float)
        Cp_  = 1/(Nmol*kT*T) * (bzavg(h_**2,b) - bzavg(h_,b)**2)
        Cp_ *= 1000
        return Cp_

    def calc_eps0(self,d_=[],v_=[],b=None):
        eq = self.equil

        if len(v_) == 0:
            d_ = self.Dips
            v_ = self.Vol

            ### 
            L1 = d_.shape[0]
            L2 = v_.shape[0]

            if L1 > L2:
                extra = L1-L2
                d_ = d_[extra+eq:]
                v_ = v_[eq:]/1000
                L = v_.shape[0]
            elif L1 < L2:
                extra = L2-L1
                d_ = d_[eq:]
                v_ = v_[eq:-extra]/1000
                L = d_.shape[0]
            else:
                d_ = d_[eq:]
                v_ = v_[eq:]/1000
                L = v_.shape[0]
        else:
            L = d_.shape[0]

        T = self.T

        if b is None: b = np.ones(L,dtype=float)
        dx = d_[:,0]
        dy = d_[:,1]
        dz = d_[:,2]
        D2  = bzavg(dx**2,b)-bzavg(dx,b)**2
        D2 += bzavg(dy**2,b)-bzavg(dy,b)**2
        D2 += bzavg(dz**2,b)-bzavg(dz,b)**2
        return prefactor*D2/bzavg(v_,b)/T

    def all_properties(self,gaslog,analyzelog=None):
        """syntax : to get all properties you must specify a path for a gas 
        log file. then, specify a liquid analyze log file.
        all_properties(gaslog,analyzelog)"""
        Nmol = self.Nmol
        NMol = self.Nmol
        
        if analyzelog is None:
            try:
                anal_fn = self.analyzelog
            except:
                print('Must specify analyze log file')
                return
        else:
            anal_fn = os.path.join(self.path,analyzelog)
        
        if os.path.isfile(anal_fn):
            f = open(anal_fn,'r')
            dt = f.readlines()
            f.close()

            log = [a.strip('\n') for a in dt]
        else:
            raise Exception('The file %s does not exist' % anal_fn)

        eanl = []
        dip = []
        vols = []
        mass = 0.0

        for ln, line in enumerate(log):
            strip = line.strip()
            s = line.split()
            if 'Total System Mass' in line:
                mass = float(s[-1])
            if 'Total Potential Energy : ' in line:
                eanl.append(float(s[4]))
            if 'Dipole X,Y,Z-Components :' in line:
                dip.append([float(s[i]) for i in range(-3,0)])
            if 'Cell Volume' in line:
                vols.append(float(s[-1]))

        
        if mass > 0:
            self.mass = mass
            
        Potentials = np.array(eanl)
        
        T = self.T
        R=1.9872036E-3
        kT = R * T

        self.RT = kT
        
        mBeta = -1.0 / kT
        Beta = 1.0 / kT

        self.PE = np.array(Potentials)

        Nmol = self.Nmol
        eq = self.equil
        self.avgPE, self.stdPE = mean_stderr(self.PE[eq:])
        self.PEmol = self.avgPE/self.Nmol
        
        self.stdPE = self.PE[eq:].std()

        Volumes = np.array(vols)

        if Volumes.shape[0] == self.PE.shape[0]:
            conv = 1.6605387831627252
            Rhos = conv * mass / Volumes
            self.avgVol, self.stdVol = mean_stderr(Volumes[eq:])
            self.avgRho, self.stdRho = mean_stderr(Rhos[eq:])
            self.Vol = np.copy(Volumes)
            self.Rhos = np.copy(Rhos)
        
        else:
            self.stdRho = self.Rhos[eq:].std()
            self.stdVol = self.Vol[eq:].std()

        if len(dip) != 0:
            self.Dips = np.array(dip)
            self.dielectric = self.calc_eps0()
        else:
            self.dielectric = 0

        if len(self.H) == 0:
            self.H = self.PE

        self.alpha = self.calc_alpha()
        self.Cp = self.calc_cp()
        self.kappa = self.calc_kappa()

        if gaslog is not None:
            if os.path.isfile(os.path.join(self.path,gaslog)):
                gas_fn = os.path.join(self.path,gaslog)
            else:
                gas_fn = gaslog
            gasdata = gas.GasLog(gas_fn,self.T)
            self.gasAvgPE = gasdata.avgPE
            self.stdGasPE = gasdata.stdPE
        
        self.HV = self.gasAvgPE - (self.PEmol) + kT
        
        # This is how I calculated the prefactor for the dielectric constant.
        # eps0 = 8.854187817620e-12 * coulomb**2 / newton / meter**2
        # epsunit = 1.0*(debye**2) / nanometer**3 / BOLTZMANN_CONSTANT_kB / kelvin
        # prefactor = epsunit/eps0/3

        #### Standard deviation
        if self.gasAvgPE > 0:
            self.stdHV = np.sqrt(gasdata.stdPE**2 + (self.stdPE/self.Nmol)**2)

        
        L = self.Rhos[eq:].shape[0]
        # N = 10000
        N = int(L/3)
        Rhoboot = []
        for i in range(numboots):
           boot = np.random.randint(L,size=N)
           Rhoboot.append(self.Rhos[eq:][boot].mean())
        Rhoboot = np.array(Rhoboot)
        Rho_err = np.std(Rhoboot)
        self.stdRho = Rho_err * np.sqrt(statisticalInefficiency(self.Rhos[eq:]))

        Alphaboot = []
        for i in range(numboots):
            boot = np.random.randint(L,size=N)
            Alphaboot.append(self.calc_alpha(self.H[eq:][boot], self.Vol[eq:][boot]))
        Alphaboot = np.array(Alphaboot)
        self.stdAlpha = np.std(Alphaboot) * max([np.sqrt(statisticalInefficiency(self.Vol[eq:])),
                                                 np.sqrt(statisticalInefficiency(self.H[eq:]))])
        
        Kappaboot = []
        for i in range(numboots):
            boot = np.random.randint(L,size=N)
            Kappaboot.append(self.calc_kappa(self.Vol[eq:][boot]))
        Kappaboot = np.array(Kappaboot)
        self.stdKappa = np.std(Kappaboot) * np.sqrt(statisticalInefficiency(self.Vol[eq:]))

        Cpboot = []
        for i in range(numboots):
            boot = np.random.randint(L,size=N)
            Cpboot.append(self.calc_cp(self.H[eq:][boot]))
        Cpboot = np.array(Cpboot)
        self.stdCp = np.std(Cpboot) * np.sqrt(statisticalInefficiency(self.H[eq:]))

        L = self.Dips[eq:].shape[0]
        if len(dip) != 0:
            Eps0boot = []
            for i in range(numboots):
                boot = np.random.randint(L,size=N)
                Eps0boot.append(self.calc_eps0(self.Dips[eq:][boot],self.Vol[eq:][boot]))
            Eps0boot = np.array(Eps0boot)
            self.stdEps = np.std(Eps0boot)*np.sqrt(np.mean([statisticalInefficiency(self.Dips[:,0][eq:]),
                                                            statisticalInefficiency(self.Dips[:,1][eq:]),
                                                            statisticalInefficiency(self.Dips[:,2][eq:])]))

    def get_dielectric(self,analyzelog):

        if os.path.isfile(os.path.join(self.path,analyzelog)):
            anal_fn = os.path.join(self.path,analyzelog)
        else:
            anal_fn = analyzelog
        
        if os.path.isfile(anal_fn):
            f = open(anal_fn,'r')
            dt = f.readlines()
            f.close()

            log = [a.strip('\n') for a in dt]
        else:
            raise Exception('The file %s does not exist' % anal_fn)

        dip = []
        for ln, line in enumerate(log):
            strip = line.strip()
            s = line.split()
            if 'Dipole X,Y,Z-Components :' in line:
                dip.append([float(s[i]) for i in range(-3,0)])

        if len(dip) == 0:
            print("No dipole moment data, dielectric will not be computed")
            Dips = []
        else:
            Dips = np.array(dip)
        
        T = self.T
        R=1.9872036E-3
        kT = R * T
        
        mBeta = -1.0 / kT
        Beta = 1.0 / kT

        eq = self.equil
        if len(dip) != 0:
            self.Dips = np.array(dip)
            self.dielectric = self.calc_eps0()
        else:
            self.dielectric = 0

    def get_diffusion(self,analyzelog):

        if os.path.isfile(os.path.join(self.path,analyzelog)):
            anal_fn = os.path.join(self.path,analyzelog)
        else:
            anal_fn = analyzelog
        
        if os.path.isfile(anal_fn):
            f = open(anal_fn,'r')
            dt = f.readlines()
            f.close()

            log = [a.strip('\n') for a in dt]
        else:
            raise Exception('The file %s does not exist' % anal_fn)


        for k,line in enumerate(log[0:500]):
            tt = line.split()
            a = len(tt)
           
            if a > 0:
                try:
                    b = float(tt[0])
                    break
                except:
                    continue
        g = log[k:]

        g_data = []
        for line in g:
            a = line.strip('\n').split()
            try:
                data = [float(n) for n in a]
                g_data.append(data)
            except:
                None

        T = self.T
        def diff_correction(box_size,T):
            const = (2.837297)/(6*np.pi)
            corr = (1e4)*const*KB_J*T/(N_vis*box_size*(1.0e-10))
            return corr

        box_size = np.cbrt(self.avgVol)
        diff_correction = diff_correction(box_size,self.T)
        g_data = np.array(g_data)
        
        self.diffusion = g_data[:,5]
        self.median_diffusion = np.median(self.diffusion)
        self.diffcorr = (1e5)*diff_correction

    def get_g_r(self,analyzelog):
        if os.path.isfile(os.path.join(self.path,analyzelog)):
            anal_fn = os.path.join(self.path,analyzelog)
        else:
            anal_fn = analyzelog
        
        if os.path.isfile(anal_fn):
            f = open(anal_fn,'r')
            dt = f.readlines()
            f.close()

            log = [a.strip('\n') for a in dt]
        else:
            raise Exception('The file %s does not exist' % anal_fn)

        for k,line in enumerate(log):
            tt = line.split()

            try:
                int(tt[0])
                begin_line = k
                break
            except:
                continue

        g = log[begin_line:]

        g_data = []
        for line in g:
            a = line.strip('\n').split()
            data = [float(n) for n in a]
            g_data.append(data)
        g_data = np.array(g_data)

        return g_data[:,2:4]

    def get_coordinates(self,arcfile=None):

        if arcfile is None:
            arc = self.xyzfile.strip('xyz')+'arc'
            arc_fn = os.path.join(self.path,arc)

        elif os.path.isfile(arcfile):
            arc_fn = arcfile
        elif os.path.isfile(os.path.join(self.path,arcfile)):
            arc_fn = os.path.join(self.path,arcfile)
        elif os.path.isfile(os.path.join(self.path,arcfile+'.arc')):
            arc_fn = os.path.join(self.path,arcfile)
        else:
            arc_fn = arcfile

        f = open(arc_fn)
        data = f.readlines()
        f.close()

        raw_arc = np.array(data)
        n_atoms = float(data[0].split()[0])
        
        del data

        try:
            box_lattice=float(raw_arc[1].split()[1])
            bg = 2
        except:
            box_lattice = 0.0
            bg = 1
            
        lines_per_frame = (n_atoms+bg)

        per_frame = np.reshape(raw_arc,(int(raw_arc.shape[0]/lines_per_frame), int(lines_per_frame)))
        
        del raw_arc

        xyz_cords = []
        
        for k,frm in enumerate(per_frame):
            
            for line in frm[bg:]:
                xyz_cords.append([float(a) for a in line.split()[2:5]])

        coords = np.reshape(np.array(xyz_cords),(per_frame.shape[0],int(n_atoms),3))
        del per_frame
        self.coords = np.copy(coords)

    def compute_avg_angle(self,atoms_index=[1,0,2],arcfile=None):

        if self.coords.shape[0] == 0:
            self.get_coordinates(arcfile)

        L = self.coords[self.equil:].shape[0]
        boot = np.random.randint(L,size=int(L/3))

        all_angles = []
        for k,xyz in enumerate(self.coords[boot]):
            a0 = atoms_index[0]
            a1 = atoms_index[1]
            a2 = atoms_index[2]
            fr_angles = [compute_angle(xyz[mol+a0],xyz[mol+a1],xyz[mol+a2]) for mol in range(0,self.Natoms-1,self.Nmonomer)]
            all_angles.append(np.array(fr_angles))

        boot = np.random.randint(L,size=int(L/3))
        for k,xyz in enumerate(self.coords[boot]):
            a0 = atoms_index[0]
            a1 = atoms_index[1]
            a2 = atoms_index[2]
            fr_angles = [compute_angle(xyz[mol+a0],xyz[mol+a1],xyz[mol+a2]) for mol in range(0,self.Natoms-1,self.Nmonomer)]
            all_angles.append(np.array(fr_angles))

        all_angles = np.array(all_angles).flatten()
        self.avg_angle, self.std_angle = mean_stderr(all_angles)
        # self.std_angle = np.std(all_angles)






    
